<?php 
# Must match the values found in the corresponding production or sandbox environment
define('ENVIRONMENT','sandbox');
define('SQUARE_APPLICATION_ID','sandbox-sq0idb-uXgCeHkLEq4jgi5QxNO_Pg');
define('SQUARE_ACCESS_TOKEN','EAAAEBD0oyongJuHSanxUhQNQYZLM_rWVUWWjHU5mKbaGQ2aDE3E8TO7NrirTdUX');
define('SQUARE_LOCATION_ID','LZTRHM1E4Y9Q8');

$environment = ENVIRONMENT;
$access_token = SQUARE_ACCESS_TOKEN;    
$location_id =  SQUARE_LOCATION_ID;

 ?>



